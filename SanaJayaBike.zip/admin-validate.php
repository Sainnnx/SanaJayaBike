<?php

session_start();

$valid_username = "SanaJayaAdmin";
$valid_password = "JayaSana2022";

if(isset($_POST["username"]) and isset ($_POST["password"])){

    if($_POST["username"]==$valid_username and $_POST["password"]==$valid_password){

        $_SESSION["stat_login"]=1;
        $_SESSION["username"]=$_POST["username"];
        $_SESSION["password"]=$_POST["password"];

        header("location:dashboard.php");
    }
    else{
        header("location:dashboard.php?halaman=input");
    }
}
else{
    echo "Data Tidak Lengkap";
}
?>